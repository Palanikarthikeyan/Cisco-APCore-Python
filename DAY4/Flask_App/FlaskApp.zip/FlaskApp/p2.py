from flask import Flask,render_template
app1 = Flask(__name__)
@app1.route("/")
def f1():
    s='''<h1><font color=green>Welcome to Enterprise Web App
    This is Home page</font></h1>'''
    return s
@app1.route("/aboutus")
def f2():
    return render_template('gpage.html')

@app1.route("/mypage")
def f3():
    mycourse = {'K1':'Python','K2':'C++','K3':'GenAI'}
    return render_template('display.html',temp_dict = mycourse)
    #courses = ['python','java','C++','GenAI','N8N']
    #return render_template('display.html',temp_var = courses)
    
    #return render_template('display.html',course='Java',duration=56)


if __name__ == '__main__':
    app1.run(debug=True)
    