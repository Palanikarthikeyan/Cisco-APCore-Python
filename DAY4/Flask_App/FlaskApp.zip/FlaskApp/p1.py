from flask import Flask

obj = Flask(__name__)

@obj.route("/") # route url (ex: https://www.google.com  https://www.abc.com)
def f1():
	return "<h2><font color=green>Welcome to Flask App</font></h2>"

@obj.route("/aboutus")
def f2():
	return "<h1><font color=blue>This is About page</font></h1>"

@obj.route("/myhome")
def f3():
    return "<h2><font color=red> My Home Page</font></h2>"

if __name__ == '__main__':
	obj.run(debug=True)