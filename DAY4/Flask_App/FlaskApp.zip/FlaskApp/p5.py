from flask import Flask,render_template,redirect,url_for

app = Flask(__name__)
@app.route("/")
def f1():
    return render_template('gpage.html')

@app.route('/mydept/<dept>')
def f2(dept):
    return f'Working dept is:{dept}'

@app.route('/user/<user>')
def f3(user):
    if(user == "admin"):
        return redirect(url_for('f1'))
    else:
        return redirect(url_for('f2',dept='sales'))
    
    
if __name__ == '__main__':
    app.run(debug=True)
    