from flask import Flask,render_template

app = Flask(__name__)
@app.route("/")
def f1():
    return render_template('gpage.html')

@app.route("/mypage/<courseName>")
def f2(courseName):
    return render_template('mydisplay.html',temp_var = courseName)
    #return f'<h2>Input Course name is:{courseName}</h2>'

if __name__ == '__main__':
    app.run(debug=True)