from flask import Flask,render_template,redirect,url_for

app = Flask(__name__)
@app.route("/")
def f1():
    return render_template('gpage.html')

@app.route("/enroll/<emp_details>")
def f2(emp_details):
    return emp_details



if __name__ == '__main__':
    app.run(debug=True)
    