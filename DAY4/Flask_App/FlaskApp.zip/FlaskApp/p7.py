from flask import Flask,redirect,url_for,request,render_template,jsonify
import json
app = Flask(__name__)

@app.route("/")
def f1():
    return "<h2>Emp enrollment details</h2>"

@app.route("/reponse1")
def f3():
    return "<h2>Enrolment is done !</h2>"

@app.route("/display",methods = ['GET','POST'])
def f2():
    if request.method == "POST":
        ename = request.form['n1']
        edob = request.form['n2']
        eplace = request.form['n3']
        return render_template('report.html',Tename=ename,Tedob=edob,Teplace=eplace)
        #return redirect(url_for('f3'))

@app.route("/data")
def f4():
    d={'K1':'V1','K2':[10,20,30]}
    return jsonify(d)
    #jd = json.dumps(d)
    #return jd # text/html format
    
@app.route("/data_display")
def f5():
    emp = [{'ename':'Arun','edob':'1st Jan','ecity':'City1'},
           {'ename':'Vijay','edob':'2nd Feb','ecity':'City2'},
           {'ename':'Anu','edob':'3rd March','ecity':'City3'}
           ]
    return jsonify(emp)

if __name__ == '__main__':
    app.run(debug=True)
    
    